<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Sigit & Faiqoh akan menikah</title>
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta content="Webflow" name="generator">
    <meta name="csrf-token" content="f6L7CM5gvdgQLkLLg01SVMxDx9yzo583Tj8IUav2">
    <meta property="og:title" content="Pernikahan Sigit & Faiqoh">
    <meta property="og:description"
        content="Undangan pernikahan Sigit & Faiqoh pada 08-01-2023 10:00 AM WIB di Jl. Pemancingan RT 07 RW 01, Gandaria Selatan, Kec. Cilandak, Jakarta Selatan.">
    <meta property="og:type" content="article" />
    <meta property="og:url" content="">
    <meta property="og:site_name" content="Undangan Online Sigit dan Faiqoh">
    <meta property="og:image" content="storage/sampul/sigitfaiqoh-banner.jpeg">
    <meta property="fb:pages" content="1032296593493301" />
    <!-- Meta Pixel Code -->
    <script>
        ! function (f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '518548139567201');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=518548139567201&ev=PageView&noscript=1" /></noscript>
    <!-- End Meta Pixel Code -->




    <style>
        @font-face

        /*perintah untuk memanggil font eksternal*/
            {
            font-family: 'Photograph Signature';
            /*memberikan nama bebas untuk font*/
            src: url('front/tema-preview/green-flower/css/Photograph Signature.ttf');
            /*memanggil file font eksternalnya di folder nexa*/
        }


        .reveal {
            position: relative;
            transform: translateY(150px);
            opacity: 0;
            transition: 1s all ease;
        }

        .reveal.active {
            transform: translateY(0);
            opacity: 1;
        }




        .youtube-video-container {
            position: relative;
            overflow: hidden;
            width: 100%;
        }

        .youtube-video-container::after {
            display: block;
            content: "";
            padding-top: 56.25%;
        }

        .youtube-video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }


        .wrapper-ucapan {
            width: 100%
        }

        .wrapper-comment {
            widows: 100%;
        }


        .hari {
            width: 20%;
            display: inline-block;
            padding: 20px;
            border-radius: 10px;
            margin: 5px;
        }



        @media screen and (max-width: 479px) {
            .wrapper-comment {
                width: 100%;
                padding: 10px;
            }

            .hari {
                width: 40%;
                display: inline-block;
                padding: 20px;
                border-radius: 10px;
                margin-top: 10px;
                margin-left: 0px;
            }

        }
    </style>

    <script type="text/javascript">
        function reveal() {
            var reveals = document.querySelectorAll(".reveal");

            for (var i = 0; i < reveals.length; i++) {
                var windowHeight = window.innerHeight;
                var elementTop = reveals[i].getBoundingClientRect().top;
                var elementVisible = 150;

                if (elementTop < windowHeight - elementVisible) {
                    reveals[i].classList.add("active");
                } else {
                    reveals[i].classList.remove("active");
                }
            }
        }

        window.addEventListener("scroll", reveal);
    </script>

    <link href="front/player.css" rel="stylesheet" type="text/css">
    <link href="front/tema/classic-2/css/themeclassic2.webflow.css" rel="stylesheet" type="text/css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Bilbo+Swash+Caps&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600&display=swap"
        rel="stylesheet">


    <link href="front/tema/classic-2/css/normalize.css" rel="stylesheet" type="text/css">

    <link href="front/tema/classic-2/css/webflow.css" rel="stylesheet" type="text/css">


    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic",
                    "Euphoria Script:regular:latin,latin-ext"
                ]
            }
        });
    </script>
    <script type="text/javascript">
        ! function (o, c) {
            var n = c.documentElement,
                t = " w-mod-";
            n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n
                .className += t + "touch")
        }(window, document);
    </script>
    <link href="front/tema/tema-kristenn/images/favicon.png" rel="shortcut icon" type="image/x-icon">
    <link href="front/tema/tema-kristenn/images/webclip.png" rel="apple-touch-icon">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
</head>

<body class="body">
    <div class="undangan-wrapper">
        <div class="cover">
            <div class="wrapper-cover">
                <img src="storage/sampul/sigitfaiqoh-banner.jpeg" loading="lazy" alt="" class="image-cover">
                <img src="front/tema/classic-2/images/bottom_decor.png" loading="lazy" alt="" class="decore_bottom">
            </div>
        </div>
        <div class="opening">
            <div class="nama-pasangan">
                <div class="_16dark bottom20 reveal" style="margin-top:40px;">Undangan Pernikahan</div>
                <div class="_16dark bottom20 tgl reveal">08 - 01 - 2023</div>
                <div class="nama top20 reveal" style="font-weight:bold;">Sigit</div>
                <div class="_16dark bottom20 reveal"
                    style="margin-top:-10px; font-style:italic; padding-left:20px; padding-right:20px;">orang tua anda
                </div>

                <div class="nama reveal">&amp;</div>
                <div class="nama bottom20 reveal" style="font-weight:bold;">Faiqoh</div>
                <div class="_16dark bottom20 reveal"
                    style="margin-top:-20px; font-style:italic;  padding-left:20px; padding-right:20px;">orang tua
                    pasangan anda</div>


            </div>
        </div>
        <div class="undangan">
            <div class="_18reg reveal">بِسْمِ اللّهِ الرَّحْمَنِ الرَّحِيْ</div>
            <div class="_16dark top20 bottom20 reveal">
                Ya Allah Ar Rohman Ar Rohim. Sesungguhnya hati ini telah terhimpun dalam cinta dan bertemu dalam taat
                kepada Mu. Eratkanlah ikatannya, kekalkanlah kasih sayangnya, berkahilah jalannya dan penuhilah hati ini
                dengan cahaya Mu yang tak pernah pudar Rasa haru dan bahagia terukir dihati kami atas limpahan Rahmat
                Allah SWT dan kami bersimpuh memohon Ridho Nya untuk melangsungkan resepsi pernikahan putra putri kami,
                yang Insya Allah akan dilaksanakan pada :
            </div>
            <div class="akad">
                <div class="title reveal">

                </div>
                <div class="detail reveal">
                    <div class="wrapper_datetime with_border">
                        <div class="waktutgl">
                            <div class="harinya">Minggu</div>
                            <div class="tanggalnya">08 Januari 2023</div>
                        </div>
                        <img src="front/tema/classic-2/images/ic_date.svg" loading="lazy" alt="" class="icon">
                    </div>
                    <div class="wrapper_datetime">
                        <img src="front/tema/classic-2/images/ic_clock.svg" loading="lazy" alt="" class="icon">
                        <div class="waktutgl">
                            <div class="harinya">
                                07:00 AM WIB
                            </div>
                            <div class="tanggalnya">
                                Sampai jika ada opsi selesai acara akad tulis disini
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_16dark top20 notop reveal">Jl. Pemancingan RT 07 RW 01, Gandaria Selatan, Kec. Cilandak,
                    Jakarta Selatan.</div>
            </div>
            <div class="akad top40">
                <div class="title reveal">

                </div>
                <div class="detail reveal">
                    <div class="wrapper_datetime with_border">
                        <div class="waktutgl">
                            <div class="harinya">Minggu</div>
                            <div class="tanggalnya">08 Januari 2023</div>
                        </div>
                        <img src="front/tema/classic-2/images/ic_date.svg" loading="lazy" alt="" class="icon">
                    </div>
                    <div class="wrapper_datetime">
                        <img src="front/tema/classic-2/images/ic_clock.svg" loading="lazy" alt="" class="icon">
                        <div class="waktutgl">
                            <div class="harinya">
                                10:00 AM WIB
                            </div>
                            <div class="tanggalnya">
                                Sampai jika ada opsi selesai acara resepsi tulis disini
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_16dark top20 notop reveal">
                    Jl. Pemancingan RT 07 RW 01, Gandaria Selatan, Kec. Cilandak, Jakarta Selatan.
                </div>
            </div>
















            <div class="akad top40">
                <div class="title reveal">Turut Mengundang</div>
                <div class="_16dark bottom20 reveal">
                    <div>nama turut mengundang1 </div>
                    <div>nama turut mengundang2 </div>
                    <div>nama turut mengundang3 </div>
                    <div>nama turut mengundang4 </div>
                    <div>nama turut mengundang5 </div>
                </div>
            </div>





        </div>
        <div class="himbauan">

            <div class="title top20 reveal" style="text-align:center; margin-top:20px; margin-bottom:20px;">Hitung
                Mundur</div>
            <div class="reveal" style="text-align: center;  font-size:36px;">
                <div class="hari" style="background:#755f4b; color:#fff;">
                    <div id="demo">00</div>
                    <div style="font-size:14px; margin-top:5px;">Hari</div>
                </div>
                <div class="hari" style="background:#755f4b; color:#fff;">
                    <div id="jam">00</div>
                    <div style="font-size:14px; margin-top:5px;">Jam</div>
                </div>
                <div class="hari" style="background:#755f4b; color:#fff;">
                    <div id="menit">00</div>
                    <div style="font-size:14px; margin-top:5px;">Menit</div>
                </div>
                <div class="hari" style="background:#755f4b; color:#fff;">
                    <div id="detik">00</div>
                    <div style="font-size:14px; margin-top:5px;">Detik</div>
                </div>

            </div>
        </div>




        <div class="album">
            <div class="title reveal">ALbum Wedding</div>
            <div class="w-layout-grid grid-photo reveal">
                <img src="storage/galeri/sigitfaiqoh-gallery1.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-gallery2.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-gallery3.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-gallery4.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-gallery5.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-gallery7.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-cover.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-hero-img.jpeg" loading="lazy" alt="" class="img">
                <img src="storage/galeri/sigitfaiqoh-banner.jpeg" loading="lazy" alt="" class="img">
            </div>
        </div>
        


        <div class="peta">
            <div class="title reveal">Peta Lokasi</div>
            <div class="petanya reveal">


                <iframe width="100%" height="300"
                    src="https://maps.google.com/maps?hl=en&amp;q=-6.2669755,106.7903499&amp;ie=UTF8&amp;t=&amp;z=15&amp;iwloc=B&amp;output=embed"
                    frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>


            </div>
        </div>


        <div class="peta">
            <div class="title reveal">Hadiah</div>
            <div class="_16dark top20 notop top reveal">
                Tanpa mengurangi rasa hormat, untuk melengkapi kebahagiaan pengantin, Anda dapat memberikan tanda kasih
                dengan transfer ke rekening/emoney berikut :<br />
                <div class="_16dark top20 notop top" style="margin-top:20px;"> BCA <br />No.Rek :
                    2860298476 <br /> a.n : Faiqoh</div>
            </div>
        </div>





        <div class="himbauan">
            <div class="himbauan-text reveal" style="padding:30px;">
                <span style="font-weight:bold;">0 tamu undangan</span> merespon akan Menghadiri Acara Pernikahan,
                Mari kirim konfirmasi kehadiran anda sekarang.
                <br />
                <input type="submit" value="Konfirmasi Kehadiran" data-wait="Please wait..."
                    class="submit-button w-button konfirmasi" style="background:#e9c061; margin-top:20px;">

            </div>
        </div>










        <div class="comment">
            <h3 class="h3 m24 ldark reveal">BERIKAN UCAPAN</h3>
            <div class="wrapper-ucapan reveal">
                <div class="form-block w-form">
                    <form method="post" action="ucapan" id="form-insert" name="email-form" data-name="Email Form"
                        class="form-ucapan">
                        <input type="hidden" name="_token" value="f6L7CM5gvdgQLkLLg01SVMxDx9yzo583Tj8IUav2"> <label
                            for="name" class="label">Nama</label>
                        <input type="hidden" class="text-field-2 w-input" maxlength="256" name="id" data-name="id"
                            value="18611" id="name" required="">
                        <input type="text" class="text-field-2 w-input" maxlength="256" name="nama" data-name="Name"
                            placeholder="Masukkan nama kamu" id="name" required="">
                        <label for="ucapan" class="label">Masukkan ucapanmu</label>
                        <textarea name="pesan" placeholder="Berikan ucapan terbaikmu untuk calon mempelai" id=""
                            cols="30" rows="" class="text-field-2 w-input"></textarea>
                        <input type="submit" value="Kirim Ucapan" data-wait="Please wait..."
                            class="submit-button w-button" style="background-color: #755f4b;"></form>
                    <div class="w-form-done">
                        <div>Thank you! Your submission has been received!</div>
                    </div>
                    <div class="w-form-fail">
                        <div>Oops! Something went wrong while submitting the form.</div>
                    </div>
                </div>
            </div>
            <div class="wrapper-comment reveal">
            </div>
        </div>
        <div class="footer">
            <div class="footer-text">made by dapa wangsaff © 2022</div>
        </div>
        <div id="backgroundaudio">
            <div class="title-music">
                <i class="zmdi zmdi-volume-up"></i>
                <div class="link">
                    <div class="text">westlife - beautiful in white</div>
                    <a href="#"></a>
                </div>
            </div>
            <audio autoplay="" controls="" loop="" preload="">
                <source src="storage/audio/1671374631.mp3" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        </div>
    </div>






    <div id="myModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-body" style="background:#d6cdbd;">

                    <div class="himbauan-text"
                        style="background:#755f4b; min-width:200px; color:#fff; border-radius:0px; ">

                        <div>Undangan Pernikahan</div>
                        <div
                            style="font-size:28px;   font-family: 'Kaushan Script', sans-serif; padding:10px; color:#FFF; padding-bottom:10px;">
                            Sigit &amp; Faiqoh </div>
                    </div>


                    <div class="wrapper-cover" style="margin-top:0px;">
                        <img src="storage/sampul/sigitfaiqoh-banner.jpeg" loading="lazy" alt="" class="image-cover">
                    </div>

                    <div>
                        <div class="himbauan-text"
                            style="background:#755f4b; min-width:200px; color:#fff; border-radius:0px; padding:5px;"
                            id="parentDiv">
                            Kepada Yth. Bapak/Ibu/Saudara/i.<br />



                        </div>
                    </div>

                    <div style="text-align:center; margin-top:10px; margin-bottom:5px;">
                        <span style="font-style:italic; font-size:12px;">*Mohon maaf bila ada kesalahan penulisan nama
                            dan gelar</span><br />
                        <a href="#"><button type="button" class="btn btn-info buka" data-dismiss="modal"
                                style="background:#755f4b;  border:#755f4b;">Buka Undangan</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="myModal2" class="modal fade">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header" style="font-family: 'Euphoria Script'; background:#f7f4ef; font-size:24px;  ">
                    <h3 class="modal-title" style="text-align:center;">
                        <center><strong>Konfirmasi Kehadiran</strong></center>
                    </h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body" style="background:#755f4b; color:#fff;">

                    <form method="post" action="rsvp" id="form-insert2" name="email-form" data-name="Email Form"
                        class="form-ucapan">
                        <input type="hidden" name="_token" value="f6L7CM5gvdgQLkLLg01SVMxDx9yzo583Tj8IUav2"> <input
                            type="hidden" class="text-field-2 w-input" maxlength="256" name="id" data-name="id"
                            value="18611" id="name" required="">
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Nama </label>
                            <input type="text" class="form-control" id="recipient-name" placeholder="Nama Anda"
                                name="nama">
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Nomor Hp </label>
                            <input type="text" class="form-control" id="recipient-name" placeholder="Nomor Anda"
                                name="telp">
                        </div>

                        <p>konfirmasi kehadiran</p>
                        <div class="form-check" style="margin-top:-10px;">
                            <input class="form-check-input" type="radio" name="konfirmasi" value="HADIR"
                                id="flexRadioDefault1" checked>
                            <label class="form-check-label" for="flexRadioDefault1">
                                Iya, saya akan datang
                            </label>
                        </div>
                        <div class="form-check" style="margin-bottom:10px;">
                            <input class="form-check-input" type="radio" name="konfirmasi" value="TIDAK HADIR"
                                id="flexRadioDefault2">
                            <label class="form-check-label" for="flexRadioDefault2">
                                Maaf, Sepertinya tidak bisa
                            </label>
                        </div>


                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"
                                style="background:#e9c061; color:#FFF; border:none;">Kirim Konfirmasi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        var countDownDate = new Date("January 8, 2023 12:00:00").getTime();

        // Perbarui hitungan mundur setiap 1 detik
        var x = setInterval(function () {

            // Dapatkan tanggal dan waktu hari ini
            var now = new Date().getTime();

            // Temukan jarak antara sekarang dan tanggal hitung mundur
            var distance = countDownDate - now;

            // Perhitungan waktu untuk hari, jam, menit dan detik
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Keluarkan hasil dalam elemen dengan id = "demo"
            document.getElementById("demo").innerHTML = days;
            // Keluarkan hasil dalam elemen dengan id = "demo"
            document.getElementById("jam").innerHTML = hours;
            // Keluarkan hasil dalam elemen dengan id = "demo"
            document.getElementById("menit").innerHTML = minutes;
            // Keluarkan hasil dalam elemen dengan id = "demo"
            document.getElementById("detik").innerHTML = seconds;



            //Jika hitungan mundur selesai, tulis beberapa teks
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("hari").innerHTML = "-";
            }
        }, 1000);
    </script>


    <script>
        // Custom Nama Tamu Undangan 
        // Ambil nilai dari parameter kepada di URL
        let urlParams = new URLSearchParams(window.location.search);
        let namaTamu = urlParams.get('kepada');

        // Tampilkan nama tamu ke dalam elemen div
        let parentDiv = document.querySelector('#parentDiv');
        let namaTamuDiv = document.createElement('div');

        namaTamuDiv.className = 'nama-tamu-undangan';
        namaTamuDiv.style.fontFamily = 'Euphoria Script';
        namaTamuDiv.style.fontSize = '24px';
        namaTamuDiv.style.padding = '5px';

        parentDiv.appendChild(namaTamuDiv);
        namaTamuDiv.innerText = namaTamu;
    </script>


    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=6018f492b0ecad3460682437"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyD865zfLtZZaH3acE8-4wxDJSn2SiU42HE"></script>
    <script src="front/tema/classic-2/js/webflow.js" type="text/javascript"></script>

    <script>
        window.addEventListener("DOMContentLoaded", event => {
            const audio = document.querySelector("audio");
            audio.volume = 0.2;
            audio.play();
        });
    </script>

    <style>
        .datclassss {
            filter: blur(5px);
            /* Browser Specific */
            -webkit-filter: blur(5px);
            -moz-filter: blur(5px);
            -o-filter: blur(5px);
            -ms-filter: blur(5px);
        }
    </style>

    <script>
        $("#form-insert").submit(function (e) {
            e.preventDefault();
            let data = new FormData(this);
            let that = this;
            $.ajax({
                url: that.action,
                type: 'POST',
                data: data,
                cache: false,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (res) {
                    if (res.message == "successfully") {

                        Swal.fire({
                            icon: 'success',
                            title: 'berhasil menambah ucapan',
                            showConfirmButton: false,
                        })
                        $(that)[0].reset();
                        setTimeout(() => {
                            window.location.href = "";
                        }, 1500);
                    }
                },
                error: function (err) {
                    if (err.status == 422) { // when status code is 422, it's a validation issue
                        let errors = [];
                        for (key in err.responseJSON.errors) {
                            errors.push(err.responseJSON.errors[key])
                        }
                        let html = '';
                        errors.map(e => {
                            html += `${e},`
                        })
                        Swal.fire({
                            icon: 'error',
                            html: listErrors = html.split(",").join("</br>")
                        })
                    }
                }
            })
        })
    </script>

    <script>
        $("#form-insert2").submit(function (e) {

            e.preventDefault();

            let data = new FormData(this);
            let that = this;
            $.ajax({
                url: that.action,
                type: 'POST',
                data: data,
                cache: false,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (res) {
                    if (res.message == "successfully") {

                        Swal.fire({
                            icon: 'success',
                            title: 'berhasil konfirmasi',
                            showConfirmButton: false,
                        })
                        $(that)[0].reset();
                        setTimeout(() => {
                            window.location.href = "";
                        }, 1500);
                    }
                },
                error: function (err) {
                    if (err.status == 422) { // when status code is 422, it's a validation issue
                        let errors = [];
                        for (key in err.responseJSON.errors) {
                            errors.push(err.responseJSON.errors[key])
                        }
                        let html = '';
                        errors.map(e => {
                            html += `${e},`
                        })
                        Swal.fire({
                            icon: 'error',
                            html: listErrors = html.split(",").join("</br>")
                        })
                    }
                }
            })
        })
    </script>

</body>

</html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function () {


        $(".buka").on('click', function () {
            const audio = document.querySelector("audio");
            audio.volume = 0.2;
            audio.play();
        });

        $(".konfirmasi").on('click', function () {
            $("#myModal2").modal('show');
        });

        $("#myModal").modal('show');

        function reveal() {
            var reveals = document.querySelectorAll(".reveal");

            for (var i = 0; i < reveals.length; i++) {
                var windowHeight = window.innerHeight;
                var elementTop = reveals[i].getBoundingClientRect().top;
                var elementVisible = 150;

                if (elementTop < windowHeight - elementVisible) {
                    reveals[i].classList.add("active");
                } else {
                    reveals[i].classList.remove("active");
                }
            }
        }
        window.addEventListener("scroll", reveal);
    });
</script>